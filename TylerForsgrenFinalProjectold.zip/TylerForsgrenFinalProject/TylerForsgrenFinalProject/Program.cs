﻿// tyler forsgren
//9/22/22
using System;
using static System.Console;
namespace TylerForsgrenFinalProject
{
    internal class Program
    {
        private static int connum;
        private static int ticks = 0;

        static void Main(string[] args)
        {
            double total = 0;
            bool endearly = false;
            double[] numbers = new double[10];
            for (int i = 0; i < numbers.Length; i++)
            {
                
                getnum();
                if (connum == 999)
                {
                    endearly = true;
                    break;
                }
                numbers[i] = connum;
            }
            for (int i = 0; i != numbers.Length; i++)
            {
                if (numbers[i] != 0)
                {
                    Write($"{numbers[i]}, ");
                    total = total + numbers[i];
                }
                
            }
            if (endearly == true)
            {
                ticks--;
            }
            Console.WriteLine($"\nThe array has {ticks} values");
            Array.Sort(numbers);
            Array.Reverse(numbers);
            Console.WriteLine($"The highest value is {numbers[0]}");
            Array.Reverse(numbers);
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] != 0)
                {
                    Console.WriteLine($"The lowest value is {numbers[i]}");
                    break;
                }

            }
            
            Console.WriteLine($"The total value is {total}");
            
            Console.WriteLine($"the average is {total / ticks}");
            
        }
        static void getnum()
        {
            bool worked = false;
            while (worked == false)
            {
                Console.Write($"Please enter an integer 999 to quit>> ");
                worked = int.TryParse(ReadLine(), out connum);
                if (worked == false)
                {
                    Console.WriteLine("\t***Invalid entry***");
                }

            }
            
            ticks++;
            //WriteLine(ticks);
        }
    }
}
